/**
 * WhatsApp Contact Button - Frontend JavaScript
 */

(function ($) {
  "use strict";

  let wcbSessionId = "";
  let wcbContactId = null;
  let wcbHasRedirected = false;

  $(document).ready(function () {
    wcbSessionId = wcbGenerateSessionId();

    if (!wcb_data || !wcb_data.whatsapp_number) {
      return;
    }

    wcbShowButton();
    wcbBindEvents();
    wcbInitAccessibility();
    wcbSetupCF7Integration();
    wcbFillHiddenFields();
  });

  function wcbShowButton() {
    const $button = $("#wcb-whatsapp-button");

    if ($button.length) {
      $button.on("click", function (e) {
        e.preventDefault();
        wcbTrackEvent("click");
        wcbOpenModal();
      });

      setTimeout(function () {
        $button.fadeIn(300);
      }, 1000);
    }
  }
  function wcbBindEvents() {
    $(document).on(
      "click",
      ".wcb-modal-close, .wcb-modal-overlay",
      wcbCloseModal
    );

    $(document).on("keydown", function (e) {
      if (e.keyCode === 27) {
        wcbCloseModal();
      }
    });

    $(document).on("click", ".wcb-modal-content", function (e) {
      e.stopPropagation();
    });

    $(document).on("click", '[onclick="wcbOpenModal()"]', function (e) {
      e.preventDefault();
      wcbTrackEvent("click");
      wcbOpenModal();
    });

    // ADICIONAR ESTA LINHA:
    $(document).on("click", ".wcb-open-modal", function (e) {
      e.preventDefault();
      wcbTrackEvent("click");
      wcbOpenModal();
    });
  }

  function wcbOpenModal() {
    const $modal = $("#wcb-modal");
    const $formContainer = $modal.find(".wcb-form-container");

    if ($modal.length) {
      $modal.addClass("wcb-modal-open");
      $("body").addClass("wcb-modal-open");

      setTimeout(function () {
        $modal.find('input[type="text"], input[type="email"]').first().focus();
      }, 300);
    }
  }

  function wcbCloseModal() {
    const $modal = $("#wcb-modal");

    if ($modal.length) {
      $modal.removeClass("wcb-modal-open");
      $("body").removeClass("wcb-modal-open");
    }
  }

  function wcbTrackEvent(eventType, contactId = null) {
    if (!wcb_data.page_data) return;

    $.ajax({
      url: wcb_data.ajax_url,
      type: "POST",
      data: {
        action: "wcb_track_event",
        nonce: wcb_data.nonce,
        event_type: eventType,
        page_title: wcb_data.page_data.title,
        page_url: wcb_data.page_data.url,
        page_slug: wcb_data.page_data.slug,
        session_id: wcbSessionId,
        contact_id: contactId,
      },
    });
  }

  function wcbSetupCF7Integration() {
    $(document).on("wpcf7mailsent", function (event) {
      if (wcbHasRedirected) return;
      wcbHasRedirected = true;

      const formElement = event.target;
      const isWhatsAppForm =
        $(formElement).find('input[name="wcb_whatsapp_form"]').length > 0;

      if (isWhatsAppForm) {
        wcbShowLoading();

        setTimeout(function () {
          $.ajax({
            url: wcb_data.ajax_url,
            type: "POST",
            data: {
              action: "wcb_process_cf7_submission",
              nonce: wcb_data.nonce,
            },
            success: function (response) {
              if (response.success && response.data.whatsapp_url) {
                wcbContactId = response.data.contact_id;
                wcbTrackEvent("redirect", wcbContactId);

                setTimeout(function () {
                  window.open(response.data.whatsapp_url, "_blank");
                  wcbHideLoading();
                  wcbCloseModal();
                }, 1000);
              } else {
                wcbHideLoading();
                wcbShowError(response.data.message || wcb_data.strings.error);
              }
            },
            error: function () {
              wcbHideLoading();
              wcbShowError(wcb_data.strings.error);
            },
          });
        }, 1000);
      }
    });

    $(document).on("wpcf7submit", function () {
      wcbTrackEvent("submit");
    });
  }

  function wcbShowLoading() {
    const $loading = $("#wcb-loading");
    if ($loading.length) {
      $loading.addClass("wcb-loading-show");
    }
  }

  function wcbHideLoading() {
    const $loading = $("#wcb-loading");
    if ($loading.length) {
      $loading.removeClass("wcb-loading-show");
    }
  }

  function wcbShowError(message) {
    alert(message);
  }

  function wcbFillHiddenFields() {
    const title = document.title;
    const url = window.location.href;
    const slug =
      window.location.pathname.split("/").filter(Boolean).pop() || "home";

    $(".wcb-page-title").val(title);
    $(".wcb-page-url").val(url);
    $(".wcb-page-slug").val(slug);

    // Se clicar no botão/modal, reforça o preenchimento com leve delay
    $(document).on("click", "#wcb-whatsapp-button", function () {
      setTimeout(() => {
        $(".wcb-page-title").val(document.title);
        $(".wcb-page-url").val(window.location.href);
        $(".wcb-page-slug").val(
          window.location.pathname.split("/").filter(Boolean).pop() || "home"
        );
      }, 100);
    });
  }

  function wcbGenerateSessionId() {
    return "wcb_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
  }

  function wcbInitAccessibility() {
    $("#wcb-whatsapp-button").attr({
      "aria-label": "Abrir chat do WhatsApp",
      role: "button",
      tabindex: "0",
    });

    $("#wcb-whatsapp-button").on("keydown", function (e) {
      if (e.keyCode === 13 || e.keyCode === 32) {
        e.preventDefault();
        $(this).click();
      }
    });

    $("#wcb-modal").attr({
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "wcb-modal-title",
    });

    $(".wcb-modal-header h3").attr("id", "wcb-modal-title");
  }

  // Expose to global
  window.wcbOpenModal = wcbOpenModal;
})(jQuery);

