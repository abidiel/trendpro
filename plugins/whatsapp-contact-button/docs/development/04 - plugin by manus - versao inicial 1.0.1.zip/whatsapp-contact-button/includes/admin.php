<?php
/**
 * Admin functionality for WhatsApp Contact Button
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class WCB_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_wcb_update_contact_status', array($this, 'ajax_update_contact_status'));
        add_action('wp_ajax_wcb_delete_contact', array($this, 'ajax_delete_contact'));
        add_action('wp_ajax_wcb_export_contacts', array($this, 'ajax_export_contacts'));
        add_action('admin_notices', array($this, 'admin_notices'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('WhatsApp Contacts', 'whatsapp-contact-button'),
            __('WhatsApp Contacts', 'whatsapp-contact-button'),
            'manage_options',
            'whatsapp-contacts',
            array($this, 'admin_page'),
            'dashicons-whatsapp',
            30
        );
    }
    
    /**
     * Initialize admin settings
     */
    public function admin_init() {
        // Register settings
        register_setting('wcb_settings', 'wcb_enabled');
        register_setting('wcb_settings', 'wcb_button_position');
        register_setting('wcb_settings', 'wcb_working_hours');
        register_setting('wcb_settings', 'wcb_form_mappings');
        register_setting('wcb_settings', 'wcb_notification_emails');
        register_setting('wcb_settings', 'wcb_delete_data_on_uninstall');
        
        // Check for dependencies
        $this->check_dependencies();
    }
    
    /**
     * Check plugin dependencies
     */
    private function check_dependencies() {
        if (!WhatsAppContactButton::is_cf7_active()) {
            add_action('admin_notices', array($this, 'cf7_missing_notice'));
        }
        
        if (!WhatsAppContactButton::is_acf_active()) {
            add_action('admin_notices', array($this, 'acf_missing_notice'));
        }
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'whatsapp-contacts') === false) {
            return;
        }
        
        wp_enqueue_style('wcb-admin-style', WCB_PLUGIN_URL . 'assets/css/admin.css', array(), WCB_PLUGIN_VERSION);
        wp_enqueue_script('wcb-admin-script', WCB_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), WCB_PLUGIN_VERSION, true);
        
        // Localize script
        wp_localize_script('wcb-admin-script', 'wcb_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wcb_admin_nonce'),
            'strings' => array(
                'confirm_delete' => __('Tem certeza que deseja deletar este contato?', 'whatsapp-contact-button'),
                'confirm_delete_multiple' => __('Tem certeza que deseja deletar os contatos selecionados?', 'whatsapp-contact-button'),
                'no_contacts_selected' => __('Nenhum contato selecionado.', 'whatsapp-contact-button'),
                'error_occurred' => __('Ocorreu um erro. Tente novamente.', 'whatsapp-contact-button')
            )
        ));
        
        // Enqueue Chart.js for analytics
        wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '3.9.1', true);
    }
    
    /**
     * Main admin page
     */
    public function admin_page() {
        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'contacts';
        
        ?>
        <div class="wrap">
            <h1><?php _e('WhatsApp Contacts', 'whatsapp-contact-button'); ?></h1>
            
            <nav class="nav-tab-wrapper">
                <a href="?page=whatsapp-contacts&tab=contacts" class="nav-tab <?php echo $active_tab == 'contacts' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Contatos', 'whatsapp-contact-button'); ?>
                </a>
                <a href="?page=whatsapp-contacts&tab=analytics" class="nav-tab <?php echo $active_tab == 'analytics' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Analytics', 'whatsapp-contact-button'); ?>
                </a>
                <a href="?page=whatsapp-contacts&tab=settings" class="nav-tab <?php echo $active_tab == 'settings' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Configurações', 'whatsapp-contact-button'); ?>
                </a>
            </nav>
            
            <div class="tab-content">
                <?php
                switch ($active_tab) {
                    case 'analytics':
                        $this->analytics_tab();
                        break;
                    case 'settings':
                        $this->settings_tab();
                        break;
                    default:
                        $this->contacts_tab();
                        break;
                }
                ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Contacts tab
     */
    private function contacts_tab() {
        // Handle bulk actions
        if (isset($_POST['action']) && $_POST['action'] !== '-1') {
            $this->handle_bulk_actions();
        }
        
        // Get filters
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $page_filter = isset($_GET['page_slug']) ? sanitize_text_field($_GET['page_slug']) : '';
        $date_from = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
        $date_to = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';
        $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
        
        // Pagination
        $per_page = 20;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;
        
        // Get contacts
        $args = array(
            'limit' => $per_page,
            'offset' => $offset,
            'status' => $status_filter,
            'page_slug' => $page_filter,
            'date_from' => $date_from,
            'date_to' => $date_to,
            'search' => $search
        );
        
        $contacts = WCB_Database::get_contacts($args);
        $total_contacts = WCB_Database::get_contacts_count($args);
        $total_pages = ceil($total_contacts / $per_page);
        
        // Get unique pages for filter
        $pages = $this->get_unique_pages();
        
        ?>
        <div class="wcb-contacts-tab">
            <!-- Filters -->
            <div class="wcb-filters">
                <form method="get" action="">
                    <input type="hidden" name="page" value="whatsapp-contacts">
                    <input type="hidden" name="tab" value="contacts">
                    
                    <div class="wcb-filter-row">
                        <select name="status">
                            <option value=""><?php _e('Todos os status', 'whatsapp-contact-button'); ?></option>
                            <option value="Novo" <?php selected($status_filter, 'Novo'); ?>><?php _e('Novo', 'whatsapp-contact-button'); ?></option>
                            <option value="Contatado" <?php selected($status_filter, 'Contatado'); ?>><?php _e('Contatado', 'whatsapp-contact-button'); ?></option>
                            <option value="Convertido" <?php selected($status_filter, 'Convertido'); ?>><?php _e('Convertido', 'whatsapp-contact-button'); ?></option>
                            <option value="Perdido" <?php selected($status_filter, 'Perdido'); ?>><?php _e('Perdido', 'whatsapp-contact-button'); ?></option>
                        </select>
                        
                        <select name="page_slug">
                            <option value=""><?php _e('Todas as páginas', 'whatsapp-contact-button'); ?></option>
                            <?php foreach ($pages as $page): ?>
                                <option value="<?php echo esc_attr($page->page_slug); ?>" <?php selected($page_filter, $page->page_slug); ?>>
                                    <?php echo esc_html($page->page_title); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <input type="date" name="date_from" value="<?php echo esc_attr($date_from); ?>" placeholder="<?php _e('Data inicial', 'whatsapp-contact-button'); ?>">
                        <input type="date" name="date_to" value="<?php echo esc_attr($date_to); ?>" placeholder="<?php _e('Data final', 'whatsapp-contact-button'); ?>">
                        
                        <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php _e('Buscar por nome, email ou telefone', 'whatsapp-contact-button'); ?>">
                        
                        <input type="submit" class="button" value="<?php _e('Filtrar', 'whatsapp-contact-button'); ?>">
                        <a href="?page=whatsapp-contacts&tab=contacts" class="button"><?php _e('Limpar', 'whatsapp-contact-button'); ?></a>
                    </div>
                </form>
            </div>
            
            <!-- Bulk actions -->
            <form method="post" id="wcb-contacts-form">
                <?php wp_nonce_field('wcb_bulk_action', 'wcb_bulk_nonce'); ?>
                
                <div class="tablenav top">
                    <div class="alignleft actions bulkactions">
                        <select name="action">
                            <option value="-1"><?php _e('Ações em massa', 'whatsapp-contact-button'); ?></option>
                            <option value="delete"><?php _e('Deletar', 'whatsapp-contact-button'); ?></option>
                            <option value="status_novo"><?php _e('Marcar como Novo', 'whatsapp-contact-button'); ?></option>
                            <option value="status_contatado"><?php _e('Marcar como Contatado', 'whatsapp-contact-button'); ?></option>
                            <option value="status_convertido"><?php _e('Marcar como Convertido', 'whatsapp-contact-button'); ?></option>
                            <option value="status_perdido"><?php _e('Marcar como Perdido', 'whatsapp-contact-button'); ?></option>
                        </select>
                        <input type="submit" class="button action" value="<?php _e('Aplicar', 'whatsapp-contact-button'); ?>">
                    </div>
                    
                    <div class="alignright actions">
                        <button type="button" class="button" id="wcb-export-contacts"><?php _e('Exportar CSV', 'whatsapp-contact-button'); ?></button>
                    </div>
                </div>
                
                <!-- Contacts table -->
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <td class="manage-column column-cb check-column">
                                <input type="checkbox" id="cb-select-all">
                            </td>
                            <th><?php _e('Nome', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Telefone', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Email', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Página', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Dispositivo', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Data', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Status', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Ações', 'whatsapp-contact-button'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($contacts)): ?>
                            <tr>
                                <td colspan="9" class="no-items"><?php _e('Nenhum contato encontrado.', 'whatsapp-contact-button'); ?></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($contacts as $contact): ?>
                                <tr>
                                    <th class="check-column">
                                        <input type="checkbox" name="contact_ids[]" value="<?php echo esc_attr($contact->id); ?>">
                                    </th>
                                    <td><strong><?php echo esc_html($contact->name); ?></strong></td>
                                    <td><?php echo esc_html($contact->phone); ?></td>
                                    <td><?php echo esc_html($contact->email); ?></td>
                                    <td>
                                        <a href="<?php echo esc_url($contact->page_url); ?>" target="_blank">
                                            <?php echo esc_html($contact->page_title); ?>
                                        </a>
                                    </td>
                                    <td><?php echo esc_html($contact->device_type); ?></td>
                                    <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($contact->submit_time))); ?></td>
                                    <td>
                                        <select class="wcb-status-select" data-contact-id="<?php echo esc_attr($contact->id); ?>">
                                            <option value="Novo" <?php selected($contact->status, 'Novo'); ?>><?php _e('Novo', 'whatsapp-contact-button'); ?></option>
                                            <option value="Contatado" <?php selected($contact->status, 'Contatado'); ?>><?php _e('Contatado', 'whatsapp-contact-button'); ?></option>
                                            <option value="Convertido" <?php selected($contact->status, 'Convertido'); ?>><?php _e('Convertido', 'whatsapp-contact-button'); ?></option>
                                            <option value="Perdido" <?php selected($contact->status, 'Perdido'); ?>><?php _e('Perdido', 'whatsapp-contact-button'); ?></option>
                                        </select>
                                    </td>
                                    <td>
                                        <button type="button" class="button button-small wcb-view-contact" data-contact-id="<?php echo esc_attr($contact->id); ?>">
                                            <?php _e('Ver', 'whatsapp-contact-button'); ?>
                                        </button>
                                        <button type="button" class="button button-small wcb-delete-contact" data-contact-id="<?php echo esc_attr($contact->id); ?>">
                                            <?php _e('Deletar', 'whatsapp-contact-button'); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="tablenav bottom">
                        <div class="tablenav-pages">
                            <?php
                            $pagination_args = array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => __('&laquo;'),
                                'next_text' => __('&raquo;'),
                                'total' => $total_pages,
                                'current' => $current_page
                            );
                            echo paginate_links($pagination_args);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            </form>
        </div>
        
        <!-- Contact details modal -->
        <div id="wcb-contact-modal" class="wcb-modal" style="display: none;">
            <div class="wcb-modal-content">
                <span class="wcb-modal-close">&times;</span>
                <h2><?php _e('Detalhes do Contato', 'whatsapp-contact-button'); ?></h2>
                <div id="wcb-contact-details"></div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Analytics tab
     */
    private function analytics_tab() {
        // Get date range
        $date_from = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : date('Y-m-d', strtotime('-30 days'));
        $date_to = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : date('Y-m-d');
        
        // Get analytics data
        $summary = WCB_Database::get_analytics_summary($date_from, $date_to);
        $top_pages = WCB_Database::get_top_pages($date_from, $date_to, 10);
        
        // Process summary data
        $analytics_data = array(
            'clicks' => 0,
            'submits' => 0,
            'redirects' => 0
        );
        
        foreach ($summary as $item) {
            if (isset($analytics_data[$item->event_type])) {
                $analytics_data[$item->event_type] = $item->count;
            }
        }
        
        // Calculate conversion rates
        $click_to_submit = $analytics_data['clicks'] > 0 ? round(($analytics_data['submits'] / $analytics_data['clicks']) * 100, 2) : 0;
        $submit_to_redirect = $analytics_data['submits'] > 0 ? round(($analytics_data['redirects'] / $analytics_data['submits']) * 100, 2) : 0;
        
        ?>
        <div class="wcb-analytics-tab">
            <!-- Date filter -->
            <div class="wcb-analytics-filters">
                <form method="get" action="">
                    <input type="hidden" name="page" value="whatsapp-contacts">
                    <input type="hidden" name="tab" value="analytics">
                    
                    <label><?php _e('Período:', 'whatsapp-contact-button'); ?></label>
                    <input type="date" name="date_from" value="<?php echo esc_attr($date_from); ?>">
                    <span><?php _e('até', 'whatsapp-contact-button'); ?></span>
                    <input type="date" name="date_to" value="<?php echo esc_attr($date_to); ?>">
                    <input type="submit" class="button" value="<?php _e('Filtrar', 'whatsapp-contact-button'); ?>">
                </form>
            </div>
            
            <!-- Summary cards -->
            <div class="wcb-analytics-cards">
                <div class="wcb-card">
                    <h3><?php _e('Cliques no Botão', 'whatsapp-contact-button'); ?></h3>
                    <div class="wcb-card-number"><?php echo number_format($analytics_data['clicks']); ?></div>
                </div>
                <div class="wcb-card">
                    <h3><?php _e('Formulários Enviados', 'whatsapp-contact-button'); ?></h3>
                    <div class="wcb-card-number"><?php echo number_format($analytics_data['submits']); ?></div>
                </div>
                <div class="wcb-card">
                    <h3><?php _e('Redirecionamentos WhatsApp', 'whatsapp-contact-button'); ?></h3>
                    <div class="wcb-card-number"><?php echo number_format($analytics_data['redirects']); ?></div>
                </div>
                <div class="wcb-card">
                    <h3><?php _e('Taxa de Conversão', 'whatsapp-contact-button'); ?></h3>
                    <div class="wcb-card-number"><?php echo $click_to_submit; ?>%</div>
                    <div class="wcb-card-subtitle"><?php _e('Cliques → Envios', 'whatsapp-contact-button'); ?></div>
                </div>
            </div>
            
            <!-- Charts -->
            <div class="wcb-analytics-charts">
                <div class="wcb-chart-container">
                    <h3><?php _e('Funil de Conversão', 'whatsapp-contact-button'); ?></h3>
                    <canvas id="wcb-funnel-chart"></canvas>
                </div>
            </div>
            
            <!-- Top pages table -->
            <div class="wcb-top-pages">
                <h3><?php _e('Top Páginas Geradoras de Leads', 'whatsapp-contact-button'); ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Página', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Cliques', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Envios', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Redirecionamentos', 'whatsapp-contact-button'); ?></th>
                            <th><?php _e('Taxa de Conversão', 'whatsapp-contact-button'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($top_pages)): ?>
                            <tr>
                                <td colspan="5"><?php _e('Nenhum dado encontrado para o período selecionado.', 'whatsapp-contact-button'); ?></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($top_pages as $page): ?>
                                <?php $conversion_rate = $page->clicks > 0 ? round(($page->submits / $page->clicks) * 100, 2) : 0; ?>
                                <tr>
                                    <td><strong><?php echo esc_html($page->page_title); ?></strong></td>
                                    <td><?php echo number_format($page->clicks); ?></td>
                                    <td><?php echo number_format($page->submits); ?></td>
                                    <td><?php echo number_format($page->redirects); ?></td>
                                    <td><?php echo $conversion_rate; ?>%</td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Funnel chart
            var ctx = document.getElementById('wcb-funnel-chart').getContext('2d');
            var funnelChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['<?php _e('Cliques', 'whatsapp-contact-button'); ?>', '<?php _e('Envios', 'whatsapp-contact-button'); ?>', '<?php _e('Redirecionamentos', 'whatsapp-contact-button'); ?>'],
                    datasets: [{
                        label: '<?php _e('Eventos', 'whatsapp-contact-button'); ?>',
                        data: [<?php echo $analytics_data['clicks']; ?>, <?php echo $analytics_data['submits']; ?>, <?php echo $analytics_data['redirects']; ?>],
                        backgroundColor: ['#25D366', '#128C7E', '#075E54'],
                        borderColor: ['#25D366', '#128C7E', '#075E54'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Settings tab
     */
    private function settings_tab() {
        // Handle form submission
        if (isset($_POST['submit']) && wp_verify_nonce($_POST['wcb_settings_nonce'], 'wcb_save_settings')) {
            $this->save_settings();
        }
        
        // Get current settings
        $enabled = WhatsAppContactButton::get_option('wcb_enabled', true);
        $button_position = WhatsAppContactButton::get_option('wcb_button_position', 'bottom-right');
        $working_hours = WhatsAppContactButton::get_option('wcb_working_hours', array());
        $form_mappings = WhatsAppContactButton::get_option('wcb_form_mappings', array());
        $notification_emails = WhatsAppContactButton::get_option('wcb_notification_emails', array(get_option('admin_email')));
        $delete_data = WhatsAppContactButton::get_option('wcb_delete_data_on_uninstall', false);
        
        // Get available CF7 forms
        $cf7_forms = $this->get_cf7_forms();
        
        ?>
        <div class="wcb-settings-tab">
            <form method="post" action="">
                <?php wp_nonce_field('wcb_save_settings', 'wcb_settings_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Ativar Plugin', 'whatsapp-contact-button'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="wcb_enabled" value="1" <?php checked($enabled); ?>>
                                <?php _e('Ativar botão WhatsApp', 'whatsapp-contact-button'); ?>
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Posição do Botão', 'whatsapp-contact-button'); ?></th>
                        <td>
                            <select name="wcb_button_position">
                                <option value="bottom-right" <?php selected($button_position, 'bottom-right'); ?>><?php _e('Inferior Direito', 'whatsapp-contact-button'); ?></option>
                                <option value="bottom-left" <?php selected($button_position, 'bottom-left'); ?>><?php _e('Inferior Esquerdo', 'whatsapp-contact-button'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <h3><?php _e('Horários de Funcionamento', 'whatsapp-contact-button'); ?></h3>
                <table class="form-table wcb-working-hours">
                    <?php
                    $days = array(
                        'monday' => __('Segunda-feira', 'whatsapp-contact-button'),
                        'tuesday' => __('Terça-feira', 'whatsapp-contact-button'),
                        'wednesday' => __('Quarta-feira', 'whatsapp-contact-button'),
                        'thursday' => __('Quinta-feira', 'whatsapp-contact-button'),
                        'friday' => __('Sexta-feira', 'whatsapp-contact-button'),
                        'saturday' => __('Sábado', 'whatsapp-contact-button'),
                        'sunday' => __('Domingo', 'whatsapp-contact-button')
                    );
                    
                    foreach ($days as $day => $label):
                        $day_settings = isset($working_hours[$day]) ? $working_hours[$day] : array('enabled' => false, 'start' => '09:00', 'end' => '18:00');
                    ?>
                        <tr>
                            <th scope="row"><?php echo $label; ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="wcb_working_hours[<?php echo $day; ?>][enabled]" value="1" <?php checked($day_settings['enabled']); ?>>
                                    <?php _e('Ativo', 'whatsapp-contact-button'); ?>
                                </label>
                                <input type="time" name="wcb_working_hours[<?php echo $day; ?>][start]" value="<?php echo esc_attr($day_settings['start']); ?>">
                                <?php _e('às', 'whatsapp-contact-button'); ?>
                                <input type="time" name="wcb_working_hours[<?php echo $day; ?>][end]" value="<?php echo esc_attr($day_settings['end']); ?>">
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
                
                <h3><?php _e('Mapeamento de Formulários por Página', 'whatsapp-contact-button'); ?></h3>
                <div class="wcb-form-mappings">
                    <p class="description"><?php _e('Configure qual formulário Contact Form 7 será exibido em cada página ou contexto.', 'whatsapp-contact-button'); ?></p>
                    
                    <div id="wcb-form-mappings-container">
                        <?php if (!empty($form_mappings)): ?>
                            <?php foreach ($form_mappings as $index => $mapping): ?>
                                <div class="wcb-form-mapping-row">
                                    <select name="wcb_form_mappings[<?php echo $index; ?>][type]">
                                        <option value="slug" <?php selected($mapping['type'], 'slug'); ?>><?php _e('Slug da Página', 'whatsapp-contact-button'); ?></option>
                                        <option value="category" <?php selected($mapping['type'], 'category'); ?>><?php _e('Categoria', 'whatsapp-contact-button'); ?></option>
                                        <option value="post_type" <?php selected($mapping['type'], 'post_type'); ?>><?php _e('Tipo de Post', 'whatsapp-contact-button'); ?></option>
                                    </select>
                                    
                                    <input type="text" name="wcb_form_mappings[<?php echo $index; ?>][value]" value="<?php echo esc_attr($mapping['value']); ?>" placeholder="<?php _e('Valor (ex: home, sobre, servicos)', 'whatsapp-contact-button'); ?>">
                                    
                                    <select name="wcb_form_mappings[<?php echo $index; ?>][form_id]">
                                        <option value=""><?php _e('Selecione um formulário', 'whatsapp-contact-button'); ?></option>
                                        <?php foreach ($cf7_forms as $form): ?>
                                            <option value="<?php echo esc_attr($form->ID); ?>" <?php selected($mapping['form_id'], $form->ID); ?>>
                                                <?php echo esc_html($form->post_title); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    
                                    <button type="button" class="button wcb-remove-mapping"><?php _e('Remover', 'whatsapp-contact-button'); ?></button>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    
                    <button type="button" class="button" id="wcb-add-mapping"><?php _e('Adicionar Mapeamento', 'whatsapp-contact-button'); ?></button>
                </div>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Emails para Notificações', 'whatsapp-contact-button'); ?></th>
                        <td>
                            <textarea name="wcb_notification_emails" rows="3" cols="50" placeholder="<?php _e('Um email por linha', 'whatsapp-contact-button'); ?>"><?php echo esc_textarea(implode("\n", $notification_emails)); ?></textarea>
                            <p class="description"><?php _e('Emails que receberão notificações de novos contatos (um por linha).', 'whatsapp-contact-button'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Desinstalação', 'whatsapp-contact-button'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="wcb_delete_data_on_uninstall" value="1" <?php checked($delete_data); ?>>
                                <?php _e('Deletar todos os dados ao desinstalar o plugin', 'whatsapp-contact-button'); ?>
                            </label>
                            <p class="description"><?php _e('ATENÇÃO: Esta ação é irreversível!', 'whatsapp-contact-button'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(__('Salvar Configurações', 'whatsapp-contact-button')); ?>
            </form>
        </div>
        
        <!-- Template for new form mapping -->
        <script type="text/template" id="wcb-form-mapping-template">
            <div class="wcb-form-mapping-row">
                <select name="wcb_form_mappings[INDEX][type]">
                    <option value="slug"><?php _e('Slug da Página', 'whatsapp-contact-button'); ?></option>
                    <option value="category"><?php _e('Categoria', 'whatsapp-contact-button'); ?></option>
                    <option value="post_type"><?php _e('Tipo de Post', 'whatsapp-contact-button'); ?></option>
                </select>
                
                <input type="text" name="wcb_form_mappings[INDEX][value]" placeholder="<?php _e('Valor (ex: home, sobre, servicos)', 'whatsapp-contact-button'); ?>">
                
                <select name="wcb_form_mappings[INDEX][form_id]">
                    <option value=""><?php _e('Selecione um formulário', 'whatsapp-contact-button'); ?></option>
                    <?php foreach ($cf7_forms as $form): ?>
                        <option value="<?php echo esc_attr($form->ID); ?>"><?php echo esc_html($form->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
                
                <button type="button" class="button wcb-remove-mapping"><?php _e('Remover', 'whatsapp-contact-button'); ?></button>
            </div>
        </script>
        <?php
    }
    
    /**
     * Save settings
     */
    private function save_settings() {
        // Sanitize and save settings
        $enabled = isset($_POST['wcb_enabled']) ? true : false;
        $button_position = sanitize_text_field($_POST['wcb_button_position']);
        $working_hours = isset($_POST['wcb_working_hours']) ? $_POST['wcb_working_hours'] : array();
        $form_mappings = isset($_POST['wcb_form_mappings']) ? $_POST['wcb_form_mappings'] : array();
        $notification_emails_raw = sanitize_textarea_field($_POST['wcb_notification_emails']);
        $delete_data = isset($_POST['wcb_delete_data_on_uninstall']) ? true : false;
        
        // Process notification emails
        $notification_emails = array_filter(array_map('trim', explode("\n", $notification_emails_raw)));
        $notification_emails = array_filter($notification_emails, 'is_email');
        
        // Process form mappings
        $clean_form_mappings = array();
        if (!empty($form_mappings)) {
            foreach ($form_mappings as $mapping) {
                if (!empty($mapping['value']) && !empty($mapping['form_id'])) {
                    $clean_form_mappings[] = array(
                        'type' => sanitize_text_field($mapping['type']),
                        'value' => sanitize_text_field($mapping['value']),
                        'form_id' => intval($mapping['form_id'])
                    );
                }
            }
        }
        
        // Save options
        WhatsAppContactButton::update_option('wcb_enabled', $enabled);
        WhatsAppContactButton::update_option('wcb_button_position', $button_position);
        WhatsAppContactButton::update_option('wcb_working_hours', $working_hours);
        WhatsAppContactButton::update_option('wcb_form_mappings', $clean_form_mappings);
        WhatsAppContactButton::update_option('wcb_notification_emails', $notification_emails);
        WhatsAppContactButton::update_option('wcb_delete_data_on_uninstall', $delete_data);
        
        add_action('admin_notices', array($this, 'settings_saved_notice'));
    }
    
    /**
     * Handle bulk actions
     */
    private function handle_bulk_actions() {
        if (!wp_verify_nonce($_POST['wcb_bulk_nonce'], 'wcb_bulk_action')) {
            return;
        }
        
        $action = sanitize_text_field($_POST['action']);
        $contact_ids = isset($_POST['contact_ids']) ? array_map('intval', $_POST['contact_ids']) : array();
        
        if (empty($contact_ids)) {
            return;
        }
        
        switch ($action) {
            case 'delete':
                WCB_Database::delete_contacts($contact_ids);
                add_action('admin_notices', array($this, 'bulk_delete_notice'));
                break;
                
            case 'status_novo':
            case 'status_contatado':
            case 'status_convertido':
            case 'status_perdido':
                $status = str_replace('status_', '', $action);
                $status = ucfirst($status);
                
                foreach ($contact_ids as $contact_id) {
                    WCB_Database::update_contact($contact_id, array('status' => $status));
                }
                add_action('admin_notices', array($this, 'bulk_status_notice'));
                break;
        }
    }
    
    /**
     * Get unique pages from contacts
     */
    private function get_unique_pages() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'whatsapp_contacts';
        
        return $wpdb->get_results("
            SELECT DISTINCT page_slug, page_title 
            FROM $table 
            WHERE page_slug != '' 
            ORDER BY page_title ASC
        ");
    }
    
    /**
     * Get Contact Form 7 forms
     */
    private function get_cf7_forms() {
        if (!WhatsAppContactButton::is_cf7_active()) {
            return array();
        }
        
        return get_posts(array(
            'post_type' => 'wpcf7_contact_form',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ));
    }
    
    /**
     * AJAX: Update contact status
     */
    public function ajax_update_contact_status() {
        check_ajax_referer('wcb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Permissão negada.', 'whatsapp-contact-button'));
        }
        
        $contact_id = intval($_POST['contact_id']);
        $status = sanitize_text_field($_POST['status']);
        
        $result = WCB_Database::update_contact($contact_id, array('status' => $status));
        
        if ($result !== false) {
            wp_send_json_success(array('message' => __('Status atualizado com sucesso.', 'whatsapp-contact-button')));
        } else {
            wp_send_json_error(array('message' => __('Erro ao atualizar status.', 'whatsapp-contact-button')));
        }
    }
    
    /**
     * AJAX: Delete contact
     */
    public function ajax_delete_contact() {
        check_ajax_referer('wcb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Permissão negada.', 'whatsapp-contact-button'));
        }
        
        $contact_id = intval($_POST['contact_id']);
        
        $result = WCB_Database::delete_contact($contact_id);
        
        if ($result !== false) {
            wp_send_json_success(array('message' => __('Contato deletado com sucesso.', 'whatsapp-contact-button')));
        } else {
            wp_send_json_error(array('message' => __('Erro ao deletar contato.', 'whatsapp-contact-button')));
        }
    }
    
    /**
     * AJAX: Export contacts
     */
    public function ajax_export_contacts() {
        check_ajax_referer('wcb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Permissão negada.', 'whatsapp-contact-button'));
        }
        
        // Get filters from request
        $filters = array(
            'status' => sanitize_text_field($_POST['status'] ?? ''),
            'page_slug' => sanitize_text_field($_POST['page_slug'] ?? ''),
            'date_from' => sanitize_text_field($_POST['date_from'] ?? ''),
            'date_to' => sanitize_text_field($_POST['date_to'] ?? ''),
            'search' => sanitize_text_field($_POST['search'] ?? ''),
            'limit' => 10000 // Large limit for export
        );
        
        $contacts = WCB_Database::get_contacts($filters);
        
        // Generate CSV
        $filename = 'whatsapp-contacts-' . date('Y-m-d-H-i-s') . '.csv';
        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['path'] . '/' . $filename;
        
        $file = fopen($file_path, 'w');
        
        // CSV headers
        $headers = array(
            __('Nome', 'whatsapp-contact-button'),
            __('Telefone', 'whatsapp-contact-button'),
            __('Email', 'whatsapp-contact-button'),
            __('Página', 'whatsapp-contact-button'),
            __('URL', 'whatsapp-contact-button'),
            __('Dispositivo', 'whatsapp-contact-button'),
            __('Data de Envio', 'whatsapp-contact-button'),
            __('Status', 'whatsapp-contact-button'),
            __('Notas', 'whatsapp-contact-button')
        );
        
        fputcsv($file, $headers);
        
        // CSV data
        foreach ($contacts as $contact) {
            $row = array(
                $contact->name,
                $contact->phone,
                $contact->email,
                $contact->page_title,
                $contact->page_url,
                $contact->device_type,
                $contact->submit_time,
                $contact->status,
                $contact->admin_notes
            );
            fputcsv($file, $row);
        }
        
        fclose($file);
        
        $file_url = $upload_dir['url'] . '/' . $filename;
        
        wp_send_json_success(array(
            'download_url' => $file_url,
            'message' => sprintf(__('Arquivo CSV gerado com %d contatos.', 'whatsapp-contact-button'), count($contacts))
        ));
    }
    
    /**
     * Admin notices
     */
    public function admin_notices() {
        // This method will be called by action hooks
    }
    
    /**
     * CF7 missing notice
     */
    public function cf7_missing_notice() {
        ?>
        <div class="notice notice-warning">
            <p><?php _e('O plugin WhatsApp Contact Button requer o Contact Form 7 para funcionar corretamente.', 'whatsapp-contact-button'); ?></p>
        </div>
        <?php
    }
    
    /**
     * ACF missing notice
     */
    public function acf_missing_notice() {
        ?>
        <div class="notice notice-warning">
            <p><?php _e('O plugin WhatsApp Contact Button requer o Advanced Custom Fields para acessar as configurações do tema.', 'whatsapp-contact-button'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Settings saved notice
     */
    public function settings_saved_notice() {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php _e('Configurações salvas com sucesso!', 'whatsapp-contact-button'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Bulk delete notice
     */
    public function bulk_delete_notice() {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php _e('Contatos deletados com sucesso!', 'whatsapp-contact-button'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Bulk status notice
     */
    public function bulk_status_notice() {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php _e('Status dos contatos atualizados com sucesso!', 'whatsapp-contact-button'); ?></p>
        </div>
        <?php
    }
}

