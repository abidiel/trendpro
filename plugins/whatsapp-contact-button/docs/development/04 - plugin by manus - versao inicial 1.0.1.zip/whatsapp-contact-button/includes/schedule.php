<?php
/**
 * Schedule functionality for WhatsApp Contact Button
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class WCB_Schedule {
    
    /**
     * Constructor
     */
    public function __construct() {
        // Schedule functionality is handled by the frontend class
        // This class can be extended for more complex scheduling features
    }
    
    /**
     * Check if current time is within working hours
     */
    public static function is_working_hours() {
        $working_hours = WhatsAppContactButton::get_option('wcb_working_hours', array());
        
        if (empty($working_hours)) {
            return true; // If no working hours set, assume always available
        }
        
        $current_time = current_time('timestamp');
        $current_day = strtolower(date('l', $current_time));
        $current_hour_minute = date('H:i', $current_time);
        
        // Map English day names to our keys
        $day_map = array(
            'monday' => 'monday',
            'tuesday' => 'tuesday',
            'wednesday' => 'wednesday',
            'thursday' => 'thursday',
            'friday' => 'friday',
            'saturday' => 'saturday',
            'sunday' => 'sunday'
        );
        
        $day_key = isset($day_map[$current_day]) ? $day_map[$current_day] : $current_day;
        
        if (!isset($working_hours[$day_key]) || !$working_hours[$day_key]['enabled']) {
            return false;
        }
        
        $start_time = $working_hours[$day_key]['start'];
        $end_time = $working_hours[$day_key]['end'];
        
        return ($current_hour_minute >= $start_time && $current_hour_minute <= $end_time);
    }
    
    /**
     * Get next working day and time
     */
    public static function get_next_working_time() {
        $working_hours = WhatsAppContactButton::get_option('wcb_working_hours', array());
        
        if (empty($working_hours)) {
            return false;
        }
        
        $current_time = current_time('timestamp');
        $days = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday');
        
        // Check next 7 days
        for ($i = 1; $i <= 7; $i++) {
            $check_time = $current_time + ($i * DAY_IN_SECONDS);
            $check_day = strtolower(date('l', $check_time));
            
            $day_map = array(
                'monday' => 'monday',
                'tuesday' => 'tuesday',
                'wednesday' => 'wednesday',
                'thursday' => 'thursday',
                'friday' => 'friday',
                'saturday' => 'saturday',
                'sunday' => 'sunday'
            );
            
            $day_key = isset($day_map[$check_day]) ? $day_map[$check_day] : $check_day;
            
            if (isset($working_hours[$day_key]) && $working_hours[$day_key]['enabled']) {
                return array(
                    'day' => $check_day,
                    'date' => date('Y-m-d', $check_time),
                    'start_time' => $working_hours[$day_key]['start'],
                    'end_time' => $working_hours[$day_key]['end']
                );
            }
        }
        
        return false;
    }
    
    /**
     * Get working hours for display
     */
    public static function get_working_hours_display() {
        $working_hours = WhatsAppContactButton::get_option('wcb_working_hours', array());
        
        if (empty($working_hours)) {
            return __('24 horas', 'whatsapp-contact-button');
        }
        
        $days_pt = array(
            'monday' => __('Segunda', 'whatsapp-contact-button'),
            'tuesday' => __('Terça', 'whatsapp-contact-button'),
            'wednesday' => __('Quarta', 'whatsapp-contact-button'),
            'thursday' => __('Quinta', 'whatsapp-contact-button'),
            'friday' => __('Sexta', 'whatsapp-contact-button'),
            'saturday' => __('Sábado', 'whatsapp-contact-button'),
            'sunday' => __('Domingo', 'whatsapp-contact-button')
        );
        
        $display = array();
        
        foreach ($working_hours as $day => $settings) {
            if ($settings['enabled']) {
                $day_name = isset($days_pt[$day]) ? $days_pt[$day] : ucfirst($day);
                $display[] = $day_name . ': ' . $settings['start'] . ' - ' . $settings['end'];
            }
        }
        
        return !empty($display) ? implode('<br>', $display) : __('Nenhum horário configurado', 'whatsapp-contact-button');
    }
    
    /**
     * Check if a specific day is enabled
     */
    public static function is_day_enabled($day) {
        $working_hours = WhatsAppContactButton::get_option('wcb_working_hours', array());
        
        return isset($working_hours[$day]) && $working_hours[$day]['enabled'];
    }
    
    /**
     * Get working hours for a specific day
     */
    public static function get_day_hours($day) {
        $working_hours = WhatsAppContactButton::get_option('wcb_working_hours', array());
        
        if (isset($working_hours[$day]) && $working_hours[$day]['enabled']) {
            return array(
                'start' => $working_hours[$day]['start'],
                'end' => $working_hours[$day]['end']
            );
        }
        
        return false;
    }
}

