/**
 * WhatsApp Contact Button - Frontend JavaScript
 * Version: 1.0.0
 */

(function($) {
    'use strict';
    
    // Global variables
    let wcbSessionId = '';
    let wcbIsWorking = true;
    let wcbContactId = null;
    
    // Initialize when document is ready
    $(document).ready(function() {
        wcbInit();
    });
    
    /**
     * Initialize the WhatsApp Contact Button
     */
    function wcbInit() {
        // Generate session ID
        wcbSessionId = wcbGenerateSessionId();
        
        // Check if plugin is enabled
        if (!wcb_data || !wcb_data.whatsapp_number) {
            return;
        }
        
        // Show the button
        wcbShowButton();
        
        // Check working hours
        wcbCheckWorkingHours();
        
        // Bind events
        wcbBindEvents();
        
        // Set up CF7 integration
        wcbSetupCF7Integration();
    }
    
    /**
     * Show the WhatsApp button
     */
    function wcbShowButton() {
        const $button = $('#wcb-whatsapp-button');
        
        if ($button.length) {
            // Add click tracking
            $button.on('click', wcbHandleButtonClick);
            
            // Show button with animation
            setTimeout(function() {
                $button.fadeIn(300);
            }, 1000);
        }
    }
    
    /**
     * Handle button click
     */
    function wcbHandleButtonClick(e) {
        e.preventDefault();
        
        // Track click event
        wcbTrackEvent('click');
        
        // Check working hours before opening modal
        if (wcbIsWorking) {
            wcbOpenModal();
        } else {
            wcbOpenModal(true); // Open with outside hours message
        }
    }
    
    /**
     * Open the modal
     */
    function wcbOpenModal(outsideHours = false) {
        const $modal = $('#wcb-modal');
        const $outsideHoursMsg = $modal.find('.wcb-outside-hours');
        const $formContainer = $modal.find('.wcb-form-container');
        
        if ($modal.length) {
            // Show/hide appropriate content
            if (outsideHours) {
                $outsideHoursMsg.show();
                $formContainer.hide();
            } else {
                $outsideHoursMsg.hide();
                $formContainer.show();
            }
            
            // Show modal
            $modal.addClass('wcb-modal-open');
            
            // Prevent body scroll
            $('body').addClass('wcb-modal-open');
            
            // Focus first input
            setTimeout(function() {
                $modal.find('input[type="text"], input[type="email"]').first().focus();
            }, 300);
        }
    }
    
    /**
     * Close the modal
     */
    function wcbCloseModal() {
        const $modal = $('#wcb-modal');
        
        if ($modal.length) {
            $modal.removeClass('wcb-modal-open');
            $('body').removeClass('wcb-modal-open');
        }
    }
    
    /**
     * Bind events
     */
    function wcbBindEvents() {
        // Modal close events
        $(document).on('click', '.wcb-modal-close, .wcb-modal-overlay', wcbCloseModal);
        
        // Escape key to close modal
        $(document).on('keydown', function(e) {
            if (e.keyCode === 27) { // ESC key
                wcbCloseModal();
            }
        });
        
        // Prevent modal content click from closing modal
        $(document).on('click', '.wcb-modal-content', function(e) {
            e.stopPropagation();
        });
        
        // Global shortcode button
        $(document).on('click', '[onclick="wcbOpenModal()"]', function(e) {
            e.preventDefault();
            wcbTrackEvent('click');
            wcbOpenModal();
        });
    }
    
    /**
     * Set up Contact Form 7 integration
     */
    function wcbSetupCF7Integration() {
        // Fill hidden fields with page data
        wcbFillHiddenFields();
        
        // Listen for CF7 events
        $(document).on('wpcf7mailsent', function(event) {
            wcbHandleCF7Success(event);
        });
        
        $(document).on('wpcf7submit', function(event) {
            wcbTrackEvent('submit');
        });
    }
    
    /**
     * Fill hidden fields with page data
     */
    function wcbFillHiddenFields() {
        if (wcb_data.page_data) {
            $('.wcb-page-title').val(wcb_data.page_data.title);
            $('.wcb-page-url').val(wcb_data.page_data.url);
            $('.wcb-page-slug').val(wcb_data.page_data.slug);
        }
    }
    
    /**
     * Handle CF7 form success
     */
    function wcbHandleCF7Success(event) {
        // Show loading overlay
        wcbShowLoading();
        
        // Wait a moment for the form to be processed
        setTimeout(function() {
            wcbProcessSubmission();
        }, 1000);
    }
    
    /**
     * Process form submission and redirect to WhatsApp
     */
    function wcbProcessSubmission() {
        $.ajax({
            url: wcb_data.ajax_url,
            type: 'POST',
            data: {
                action: 'wcb_process_cf7_submission',
                nonce: wcb_data.nonce
            },
            success: function(response) {
                if (response.success) {
                    wcbContactId = response.data.contact_id;
                    
                    // Track redirect event
                    wcbTrackEvent('redirect', wcbContactId);
                    
                    // Redirect to WhatsApp
                    setTimeout(function() {
                        window.open(response.data.whatsapp_url, '_blank');
                        wcbHideLoading();
                        wcbCloseModal();
                    }, 1500);
                } else {
                    wcbHideLoading();
                    wcbShowError(response.data.message || wcb_data.strings.error);
                }
            },
            error: function() {
                wcbHideLoading();
                wcbShowError(wcb_data.strings.error);
            }
        });
    }
    
    /**
     * Show loading overlay
     */
    function wcbShowLoading() {
        const $loading = $('#wcb-loading');
        if ($loading.length) {
            $loading.addClass('wcb-loading-show');
        }
    }
    
    /**
     * Hide loading overlay
     */
    function wcbHideLoading() {
        const $loading = $('#wcb-loading');
        if ($loading.length) {
            $loading.removeClass('wcb-loading-show');
        }
    }
    
    /**
     * Show error message
     */
    function wcbShowError(message) {
        alert(message); // Simple alert for now, can be enhanced with custom modal
    }
    
    /**
     * Check working hours
     */
    function wcbCheckWorkingHours() {
        $.ajax({
            url: wcb_data.ajax_url,
            type: 'POST',
            data: {
                action: 'wcb_check_working_hours',
                nonce: wcb_data.nonce
            },
            success: function(response) {
                if (response.success) {
                    wcbIsWorking = response.data.is_working_hours;
                }
            }
        });
    }
    
    /**
     * Track events for analytics
     */
    function wcbTrackEvent(eventType, contactId = null) {
        if (!wcb_data.page_data) {
            return;
        }
        
        $.ajax({
            url: wcb_data.ajax_url,
            type: 'POST',
            data: {
                action: 'wcb_track_event',
                nonce: wcb_data.nonce,
                event_type: eventType,
                page_title: wcb_data.page_data.title,
                page_url: wcb_data.page_data.url,
                page_slug: wcb_data.page_data.slug,
                session_id: wcbSessionId,
                contact_id: contactId
            }
        });
    }
    
    /**
     * Generate session ID
     */
    function wcbGenerateSessionId() {
        return 'wcb_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    /**
     * Get device type
     */
    function wcbGetDeviceType() {
        const userAgent = navigator.userAgent.toLowerCase();
        
        if (/tablet|ipad|playbook|silk/i.test(userAgent)) {
            return 'tablet';
        } else if (/mobile|iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(userAgent)) {
            return 'mobile';
        } else {
            return 'desktop';
        }
    }
    
    /**
     * Utility function to format phone number
     */
    function wcbFormatPhone(phone) {
        // Remove all non-numeric characters
        return phone.replace(/\D/g, '');
    }
    
    /**
     * Utility function to validate email
     */
    function wcbValidateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    /**
     * Handle window resize for responsive behavior
     */
    $(window).on('resize', function() {
        // Adjust modal position if needed
        const $modal = $('#wcb-modal');
        if ($modal.hasClass('wcb-modal-open')) {
            // Modal positioning is handled by CSS, but we can add custom logic here if needed
        }
    });
    
    /**
     * Handle page visibility change
     */
    $(document).on('visibilitychange', function() {
        if (document.hidden) {
            // Page is hidden, pause any ongoing operations
        } else {
            // Page is visible, resume operations
            wcbCheckWorkingHours(); // Re-check working hours when page becomes visible
        }
    });
    
    /**
     * Accessibility improvements
     */
    function wcbInitAccessibility() {
        // Add ARIA labels
        $('#wcb-whatsapp-button').attr({
            'aria-label': 'Abrir chat do WhatsApp',
            'role': 'button',
            'tabindex': '0'
        });
        
        // Handle keyboard navigation
        $('#wcb-whatsapp-button').on('keydown', function(e) {
            if (e.keyCode === 13 || e.keyCode === 32) { // Enter or Space
                e.preventDefault();
                $(this).click();
            }
        });
        
        // Modal accessibility
        $('#wcb-modal').attr({
            'role': 'dialog',
            'aria-modal': 'true',
            'aria-labelledby': 'wcb-modal-title'
        });
        
        $('.wcb-modal-header h3').attr('id', 'wcb-modal-title');
    }
    
    // Initialize accessibility features
    $(document).ready(function() {
        wcbInitAccessibility();
    });
    
    // Expose global function for shortcode usage
    window.wcbOpenModal = wcbOpenModal;
    
})(jQuery);

