=== WhatsApp Contact Button ===
Contributors: manusai
Tags: whatsapp, contact, button, contact-form-7, analytics, leads, theme-integration
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Plugin WordPress para botão de contato WhatsApp com integração CF7, funcionalidades de rastreamento e integração inteligente com cores do tema.

== Description ==

O WhatsApp Contact Button é um plugin WordPress completo que adiciona um botão flutuante de WhatsApp ao seu site, captura leads através de formulários Contact Form 7 e oferece um sistema completo de analytics e gerenciamento de contatos. **Novo na v1.0.1**: Integração inteligente com a variável CSS `--base-color` do seu tema!

= Principais Funcionalidades =

* **Botão Flutuante WhatsApp**: Botão fixo e responsivo com design minimalista
* **Integração com Tema**: Usa automaticamente a variável `--base-color` do seu tema
* **Modal Inteligente**: Popup com conteúdo dinâmico por página usando campos ACF
* **Integração Contact Form 7**: Captura automática de dados e redirecionamento para WhatsApp
* **Sistema de Analytics**: Rastreamento completo de cliques, envios e conversões
* **Painel Administrativo**: Gerenciamento completo de contatos e métricas
* **Horários de Funcionamento**: Configuração de dias e horários de atendimento
* **Notificações por Email**: Alertas automáticos para novos contatos
* **Exportação de Dados**: Export CSV com filtros avançados

= Integração com Cores do Tema =

**Novidade v1.0.1**: O plugin detecta automaticamente a variável CSS `--base-color` do seu tema e aplica em elementos estratégicos:

* Campos de formulário em foco
* Checkboxes e elementos interativos  
* Botões secundários e links
* Elementos do painel administrativo
* Mantém o verde tradicional do WhatsApp no botão principal

= Shortcode Flexível =

```
[whatsapp_button text="Fale Conosco" style="theme"]
[whatsapp_button text="WhatsApp" style="whatsapp"]
```

Parâmetros:
* `text`: Texto do botão
* `style`: "theme" (usa cor do tema) ou "whatsapp" (verde tradicional)
* `class`: Classe CSS adicional

= Integração com ACF =

O plugin utiliza campos Advanced Custom Fields nas opções do tema:
* `whatsapp` - Número do WhatsApp
* `whatsapp_texto_popup` - Texto do popup
* `whatsapp_mensagem_base` - Mensagem base do WhatsApp

= Requisitos =

* WordPress 5.0 ou superior
* PHP 7.4 ou superior
* Contact Form 7 (recomendado)
* Advanced Custom Fields (recomendado)

= Compatibilidade =

* Funciona com qualquer tema WordPress
* Responsivo para desktop e mobile
* Compatível com plugins de cache
* Não interfere com webhooks existentes do CF7

== Installation ==

1. Faça upload do plugin para o diretório `/wp-content/plugins/`
2. Ative o plugin através do menu 'Plugins' no WordPress
3. Configure os campos ACF nas opções do tema (se usando ACF)
4. Acesse 'WhatsApp Contacts' no menu administrativo para configurar
5. Configure os formulários Contact Form 7 desejados
6. Defina os horários de funcionamento e emails de notificação

= Configuração Inicial =

1. **Campos ACF**: Crie os campos necessários nas opções do tema
2. **Formulários CF7**: Configure os formulários com campos: nome, email, telefone
3. **Mapeamento**: Configure qual formulário aparece em cada página
4. **Horários**: Defina os dias e horários de atendimento
5. **Notificações**: Configure os emails que receberão alertas

== Frequently Asked Questions ==

= O plugin funciona sem Contact Form 7? =

Sim, mas a funcionalidade de captura de leads ficará limitada. Recomendamos o uso do CF7 para melhor experiência.

= É necessário ter Advanced Custom Fields? =

Não é obrigatório, mas recomendado. Sem ACF, você precisará configurar o número do WhatsApp diretamente no código.

= O plugin afeta a velocidade do site? =

Não. Os assets são carregados apenas quando necessário e o código é otimizado para performance.

= Posso personalizar o design do botão? =

Sim, através de CSS customizado. O plugin oferece classes CSS específicas para personalização.

= Os dados dos contatos ficam seguros? =

Sim. Todos os dados são armazenados no banco de dados do WordPress com sanitização adequada.

= Posso usar em múltiplos sites? =

Sim, o plugin pode ser usado em quantos sites desejar, seguindo a licença GPL.

== Screenshots ==

1. Botão flutuante do WhatsApp no frontend
2. Modal com formulário Contact Form 7
3. Painel administrativo - Lista de contatos
4. Painel administrativo - Analytics e métricas
5. Painel administrativo - Configurações
6. Exemplo de notificação por email

== Changelog ==

= 1.0.1 =
* **Nova funcionalidade**: Integração automática com variável CSS `--base-color` do tema
* **Melhoria**: Shortcode com parâmetro `style` para escolher entre cor do tema ou verde WhatsApp
* **Melhoria**: Elementos do painel administrativo agora seguem a cor do tema
* **Melhoria**: Campos de formulário com foco usando cor do tema
* **Melhoria**: Sistema de fallback inteligente para navegadores antigos
* **Correção**: Erro fatal durante ativação do plugin (classe WCB_Database não encontrada)
* **Documentação**: Novo arquivo THEME-INTEGRATION.md com guia completo

= 1.0.0 =
* Lançamento inicial
* Botão flutuante WhatsApp com modal
* Integração completa com Contact Form 7
* Sistema de analytics e rastreamento
* Painel administrativo completo
* Horários de funcionamento configuráveis
* Notificações por email automáticas
* Exportação CSV de contatos
* Suporte a múltiplos formulários por página
* Design responsivo e acessível

== Upgrade Notice ==

= 1.0.1 =
Nova integração com cores do tema! O plugin agora usa automaticamente a variável --base-color do seu tema para uma aparência mais harmoniosa. Correção importante de erro fatal na ativação.

= 1.0.0 =
Primeira versão do plugin. Instale para começar a capturar leads via WhatsApp.

== Technical Details ==

= Estrutura do Plugin =

* `whatsapp-contact-button.php` - Arquivo principal
* `includes/` - Classes e funcionalidades PHP
* `assets/` - CSS, JavaScript e imagens
* Tabelas de banco: `wp_whatsapp_contacts` e `wp_whatsapp_analytics`

= Hooks e Filtros =

O plugin oferece diversos hooks para desenvolvedores:

* `wcb_before_contact_insert` - Antes de inserir contato
* `wcb_after_contact_insert` - Após inserir contato
* `wcb_whatsapp_message` - Filtrar mensagem do WhatsApp
* `wcb_notification_emails` - Filtrar emails de notificação

= Shortcodes =

* `[whatsapp_button]` - Botão manual do WhatsApp
* Parâmetros: `text`, `class`

= Funções Úteis =

* `WhatsAppContactButton::get_whatsapp_number()` - Obter número limpo
* `WhatsAppContactButton::is_cf7_active()` - Verificar se CF7 está ativo
* `WCB_Schedule::is_working_hours()` - Verificar horário de funcionamento

== Support ==

Para suporte técnico, documentação adicional ou reportar bugs:

* Documentação: Incluída no plugin
* Suporte: Através do desenvolvedor
* GitHub: [Link do repositório se disponível]

== Privacy Policy ==

Este plugin coleta e armazena as seguintes informações:

* Nome, email e telefone dos visitantes (via formulários)
* URL da página de origem
* Tipo de dispositivo e user agent
* Timestamps de interações

Todos os dados são armazenados localmente no banco de dados do WordPress e não são enviados para serviços externos, exceto:

* WhatsApp (quando o usuário é redirecionado)
* Emails de notificação (enviados via sistema de email do WordPress)

Os dados podem ser exportados ou deletados através do painel administrativo.

== Credits ==

Desenvolvido por Manus AI com foco em simplicidade, performance e funcionalidade completa para captura de leads via WhatsApp.

Ícones: WhatsApp oficial
Inspiração: Necessidades reais de negócios digitais
Tecnologias: WordPress, PHP, JavaScript, CSS3

